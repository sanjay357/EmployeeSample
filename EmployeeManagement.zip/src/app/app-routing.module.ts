import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeesListComponent } from './Employees/employees-list/employees-list.component';
import { EmployeedetailsComponent } from './Employees/employeedetails/employeedetails.component';
import { PagenotfoundComponent } from './Employees/pagenotfound/pagenotfound.component';
import { LoginComponent } from './login/login/login.component';
import { AuthguardService } from './Services/authguard.service';

const routes: Routes = [
  {path: 'login', component: LoginComponent},
  {path: 'employees', component: EmployeesListComponent, canActivate: [AuthguardService]},
  {path: 'employee/:id', component: EmployeedetailsComponent, canActivate: [AuthguardService]},
  {path: '', redirectTo: '/login', pathMatch: 'full'},
  {path: '**', component: PagenotfoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
