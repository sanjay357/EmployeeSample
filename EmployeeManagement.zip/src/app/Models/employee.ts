export class Employee {
    Name: string;
    Id: number;
    Age: number;
    Mobile: number;
}
