export class Userinfo {
    UserName: string;
    Password: string;

}
