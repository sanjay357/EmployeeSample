import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeesListComponent } from './Employees/employees-list/employees-list.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import {MatTableModule} from '@angular/material/table';
import { MatSortModule } from '@angular/material/sort';
import {MatInputModule} from '@angular/material/input';
import { EmployeedetailsComponent } from './Employees/employeedetails/employeedetails.component';
import { PagenotfoundComponent } from './Employees/pagenotfound/pagenotfound.component';
import { LoginComponent } from './login/login/login.component';
import { FormsModule } from '@angular/forms';
import { AuthguardService } from './Services/authguard.service';

@NgModule({
  declarations: [
    AppComponent,
    EmployeesListComponent,
    EmployeedetailsComponent,
    PagenotfoundComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    FormsModule,
    MatTableModule,
    MatSortModule,
    MatInputModule
  ],
  providers: [AuthguardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
