import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/Services/login.service';
import { Userinfo } from 'src/app/Models/userinfo';
import { Router } from '@angular/router';
import { ConsoleReporter } from 'jasmine';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  users: Userinfo[];

  userName: string;
  passWord: string;
  status: string;
  isAuthorizedUser: string = 'N';

  constructor(private loginService: LoginService, private route: Router) { }

  ngOnInit(): void {
    this.loginService.getUserInfo().subscribe(s => this.users = s);
    this.status = "";
  }

  ValidateUser(): void {
    var count = this.users.filter(m => m.UserName == this.userName && m.Password == this.passWord).length;

    if (count > 0) {
      this.isAuthorizedUser='Y';
      localStorage.setItem('userStatus', this.isAuthorizedUser);
      console.log(localStorage.getItem('userStatus'));

      this.route.navigate(['/employees']);
      this.status = "";
    }
    else {
      this.isAuthorizedUser='N';
      localStorage.setItem('userStatus', this.isAuthorizedUser);
      this.status = "User has no Access!";
    }


  }
}
