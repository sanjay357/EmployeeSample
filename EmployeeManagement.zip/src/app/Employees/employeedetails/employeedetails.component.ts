import { Component, OnInit, Input } from '@angular/core';
import { EmployeeService } from 'src/app/Services/employee.service';
import { Employee } from 'src/app/Models/employee';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { Location} from '@angular/common';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {

  @Input() id: number;

  employees: Employee[];
  employee: Employee = new Employee();

  constructor(private employeeService: EmployeeService, private activatedRoute: ActivatedRoute, private location: Location) { }

  ngOnInit(): void {
    this.employeeService.getEmployeesList().subscribe(s=> 
      {
        this.employees = s;
        this.getEmployee(this.employees);
      }
      );
  }

  getEmployee(employeeList: Employee[]): void  {
    const empId = +this.activatedRoute.snapshot.paramMap.get('id');
    this.employee = employeeList.find(m=> m.Id == empId);
  }

  GoBackToList()
  {
    this.location.back();
  }
}
