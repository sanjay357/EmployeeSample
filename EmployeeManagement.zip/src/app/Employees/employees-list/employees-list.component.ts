import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Employee } from 'src/app/Models/employee';
import { EmployeeService } from 'src/app/Services/employee.service';
import { MatSort } from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.css']
})
export class EmployeesListComponent implements OnInit {

  employeesList: Employee[];
  displayedColumns: String[]= ['Id','Name'];
  @ViewChild(MatSort) sort: MatSort;
  dataSource = new MatTableDataSource<Employee>();

  constructor(private employeeService: EmployeeService, private route: Router) 
  {
    
   }

  ngOnInit(): void {
    this.getEmployees();
  }


  getEmployees(): void
  {
    this.employeeService.getEmployeesList().subscribe(s=> 
      { 
        this.employeesList = s;
        this.dataSource = new MatTableDataSource<Employee>(this.employeesList);
        this.dataSource.sort = this.sort;
        console.log(this.employeesList);
      } 
      );
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  public highlightSelectedRow(row): void
  {
      this.route.navigate(['/employee', row.Id ]);
  }

}
