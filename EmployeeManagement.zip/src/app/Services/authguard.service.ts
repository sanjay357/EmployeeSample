import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthguardService implements CanActivate{

  canActivate(route: import("@angular/router").ActivatedRouteSnapshot): boolean {
 
    var status = localStorage.getItem('userStatus');
 
    console.log(status);

    if(status == 'Y')
    {
      return true;
    }

    else
    {
      return false;
    }

  }

  constructor() { }
}
