import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Userinfo } from '../Models/userinfo';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private webRequest: HttpClient) { }

  getUserInfo(): Observable<Userinfo[]>
  {
    return this.webRequest.get<Userinfo[]>("http://localhost:3000/UserInfo");
  }

}
