import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Employee } from '../Models/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  
  employeeApiURL: string =  "http://localhost:3000/Employees";

  constructor(private webRequest: HttpClient) { }
  
  getEmployeesList(): Observable<Employee[]>
  {
    return this.webRequest.get<Employee[]>(this.employeeApiURL);
  }
  
}
